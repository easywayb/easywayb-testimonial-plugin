jQuery(document).ready(function($) {
	jQuery('.ewb-carousel').carousel({
        indicators: true
	});
	setInterval(function() {
 
        jQuery('.ewb-carousel').carousel('next');
     
    }, 4500);   
    
jQuery('.ewb-prev').click(function() {
    jQuery('.ewb-carousel').carousel('prev');
});

jQuery('.ewb-next').click(function() {
    jQuery('.ewb-carousel').carousel('next');
});
});
