=== EasyWayB Testimonials ===
Contributors: EasyWayB
Plugin Name: EasyWayB Testimonials 
Plugin URI: https://www.easywayb.com/discussion/easywayb-testimonials-plugin/
Description: Plugin to registers a post type as testimonial and display from shortcode as slider.
Version: 1.0
Author: EasyWayB
Author URI: https://easywayb.com/
License: GPLv2 or later
Text Domain: easywayb
License URI: http://www.gnu.org/licenses/gpl-2.0.html

BASIC INPUT FIELDS
------------------
Testimonial image
Testimonial title or Tagline
Testimonial content or Review message

FEATURES OF THIS PLUGIN
-----------------------
Fully Responsive and Mobile friendly.
Easy To Use – No Coding Required.
Shortcode Generator with live preview.

SHORTCODE
[ewb-testimonial count="10" order="ASC" orderby="date"]